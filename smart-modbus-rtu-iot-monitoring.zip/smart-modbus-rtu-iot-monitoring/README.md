# Smart Fault-Tolerant Sensor Monitoring System
See documentation inside.