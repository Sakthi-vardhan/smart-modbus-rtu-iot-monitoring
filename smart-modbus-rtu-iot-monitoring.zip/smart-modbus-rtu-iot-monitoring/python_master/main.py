# Python master entry point
print('Smart Modbus RTU IoT Monitoring')